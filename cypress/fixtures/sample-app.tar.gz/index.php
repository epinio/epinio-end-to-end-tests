<?php

phpinfo()

?>
